//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CollectionFichiers.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_COLLECTIONFICHIERS_FORM     101
#define IDR_COLLECTIONFICHIERS          102
#define IDB_SPLASH                      103
#define IDB_LIGHTBULB                   112
#define IDD_TIP                         113
#define CG_IDS_TIPOFTHEDAY              114
#define CG_IDS_TIPOFTHEDAYMENU          115
#define CG_IDS_DIDYOUKNOW               116
#define CG_IDS_FILE_ABSENT              117
#define CG_IDP_FILE_CORRUPT             118
#define CG_IDS_TIPOFTHEDAYHELP          119
#define IDR_MAINFRAME                   128
#define IDR_COLLECTYPE                  129
#define IDS_AJOUT_FICHIERS              129
#define IDI_ICON1                       133
#define IDI_ICON2                       134
#define IDD_SCANNING                    134
#define IDD_LISTE_ATTRIBUTS             135
#define IDI_ICON3                       135
#define IDI_ICON4                       136
#define IDR_REGROUPE                    136
#define IDR_AVI1                        138
#define IDC_LISTE                       1000
#define IDC_BULB                        1000
#define IDC_STARTUP                     1001
#define IDC_NEXTTIP                     1002
#define IDC_HEADER                      1003
#define IDC_TIPSTRING                   1004
#define IDC_LISTE_ATTRIBUTS             1005
#define IDC_EDIT1                       1006
#define IDC_EDIT2                       1008
#define IDC_BUTTON2                     1009
#define IDC_BUTTON3                     1010
#define IDC_BUTTON4                     1011
#define IDC_COMBO1                      1012
#define IDC_BUTTON1                     1013
#define IDC_FILTRER                     1013
#define IDC_LISTE_ATTRIBUS              1014
#define IDC_TEXTE                       1015
#define IDC_PROGRESS                    1016
#define IDC_FICHIER                     1019
#define IDC_CHECKSUM                    1020
#define IDC_ANIMATE1                    1033
#define ID_BUTTON32772                  32772
#define ID_FICHIERS_AJOUTER             32773
#define ID_FICHIERS_SUPPRIMER           32775
#define ID_BUTTON32776                  32776
#define ID_BUTTON32777                  32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           120
#endif
#endif
